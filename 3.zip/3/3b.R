num <- c(1, 2 ,3 ,4 ,5)
char <- c('abcd', 'efgh', 'ijkl')
log <- c(TRUE, FALSE, TRUE, TRUE)
class(num)
class(char)
class(log)
l <- list(num, char, log)
l
