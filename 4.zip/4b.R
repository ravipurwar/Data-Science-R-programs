boxplot(Weight ~ Date, data = cabbage_exp, xlab = 'Dates', ylab = 'Weight')
